const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const D=require('../dynamics.js');
const ScreenSplash=require('../screen-splash.js');
for(const hz of [20,30,60,120]){
  let y=1.2,v=-5,min=y;
  for(let i=0;i<hz*3;i++){const r=D.spring(y,v,1.2,1/hz);y=r.value;v=r.velocity;min=Math.min(min,y);}
  assert(min<1.0);assert(Math.abs(y-1.2)<.01);
}
for(const hz of [20,30,60,120]){
  const e=D.createWaterEntry(0,-22,0,.5);let min=0,deepTime=0,peakTime=0,previous=0,recovering=false;
  assert.equal(e.velocity,-22,'impact velocity must survive contact');
  for(let i=0;i<hz*5;i++){
    D.stepWaterEntry(e,1/hz);
    if(e.offset<min){min=e.offset;peakTime=e.age;}
    if(e.offset<-1.5)deepTime+=1/hz;
    if(recovering)assert(e.offset>=previous-1e-8,'recovery stays monotonic');
    if(e.velocity>=0)recovering=true;
    assert(e.offset<=0,'no artificial upward rebound');previous=e.offset;
  }
  assert(min<-3.5&&min>-4.2);assert(peakTime>.4&&peakTime<.6);
  assert(deepTime>1.25,'immersion lasts, rather than being a short dip');assert(e.done);
}
for(const speed of [30,52,80])for(const lat of [-68,68])for(const skill of [0,1]){
  const f={t:.8,lat:-lat*.8,kind:'ramp'},a={t:0,lat,curV:speed,skill};let calls=0,decisionDistance=0;
  while(a.t<.8){
    const target=D.chooseRoute(a,[f],1000,1/60,()=>{calls++;decisionDistance=(f.t-a.t)*1000;return .5;});
    a.lat+=Math.max(-16/60,Math.min(16/60,target-a.lat));a.t+=speed/60000;
  }
  assert.equal(calls,1,'one probability roll per encounter');
  assert(skill?Math.abs(a.lat-f.lat)<2:Math.abs(a.lat-f.lat)>10);
  assert(decisionDistance>0);
}
// Execute the real scene and game logic with only the WebGL renderer stubbed.
const THREE=require('../three.min.js');
THREE.WebGLRenderer=class{constructor(){this.domElement={};this.shadowMap={};this.capabilities={getMaxAnisotropy:()=>4};this.info={render:{calls:0}};}setSize(){}setPixelRatio(){}getPixelRatio(){return 1;}setRenderTarget(){}render(){}};
THREE.PMREMGenerator=class{fromScene(){return {texture:new THREE.Texture()};}dispose(){}};
const elements=new Map(),element=()=>({style:{},dataset:{},children:[],setAttribute(){},appendChild(child){this.children.push(child);},classList:{add(){},remove(){}},addEventListener(){}});
const document={body:{appendChild(){}},getElementById(id){if(!elements.has(id))elements.set(id,element());return elements.get(id);},createElement(tag){return tag==='canvas'?{getContext:()=>({fillRect(){},strokeRect(){}})}:element();}};
let seed=93461;const math=Object.create(Math);math.random=()=>((seed=(1664525*seed+1013904223)>>>0)/4294967296);
const ctx=vm.createContext({THREE,BoatDynamics:{...D,chooseRoute:(a,f,length,dt)=>D.chooseRoute(a,f,length,dt,math.random)},ScreenSplash,document,window:{},innerWidth:1280,innerHeight:720,devicePixelRatio:1,addEventListener(){},requestAnimationFrame(){},setTimeout(){},location:{search:''},URLSearchParams,performance,console,Math:math});
const html=fs.readFileSync(require('node:path').join(__dirname,'../index.html'),'utf8');
vm.runInContext(html.match(/<script>\s*([\s\S]*?)<\/script>/)[1],ctx);
function test(code){return vm.runInContext(code,ctx);}

const balance=test(`(()=>{
 started=true;keys.w=true;
 ais.forEach(a=>{a.baseSpeed=57;a.skill=.85;});
 let lane=-20, boostCount=0,wasBonus=0;
 for(let i=0;i<240*60;i++){
  const dt=1/60;raceTime=i*dt;
  const next=features.map(f=>({f,d:BoatDynamics.featureDistance(player.prog,f,curveLen)})).sort((a,b)=>a.d-b.d)[0];
  let desired=48;
  if(next.d<300){
   const f=next.f;
   desired=f.kind==='bridge'?f.openings.reduce((best,o)=>Math.abs(o-lane)<Math.abs(best-lane)?o:best):f.kind==='boost'?f.lat:Math.abs(f.lat-48)<20?f.lat-23:48;
  }
  lane+=THREE.MathUtils.clamp(desired-lane,-12*dt,12*dt);
  const look=Math.max(30,player.v*.7),target=curveAt(player.prog+look/curveLen),dir=tangentAt(player.prog+look/curveLen);
  target.x-=dir.z*lane;target.z+=dir.x*lane;
  const delta=Math.atan2(Math.sin(Math.atan2(target.x-player.x,target.z-player.z)-player.heading),Math.cos(Math.atan2(target.x-player.x,target.z-player.z)-player.heading));
  const control=delta*3-(player.yawVel||0)*1.1;keys.a=control>.02;keys.d=control<-.02;
  updatePlayer(dt,raceTime);updateAI(dt,raceTime);
  if((player.bonus||0)>wasBonus+10)boostCount++;wasBonus=player.bonus||0;
  if(player.finished&&ais.every(a=>a.finished))break;
 }
 return {player:player.finishTime,hits:player.hits,boostCount,ai:ais.map(a=>a.finishTime),progress:player.prog};
})()`);
assert(balance.player>0 && balance.ai.every(time=>time>balance.player+3),JSON.stringify(balance));
console.log("PASS: fastest/highest-skill opponents remain beatable with player controls",balance);
